

<b> 
<center>
<h1 style="background-color: white;"> Delete Patient Apponiment </h1>
</b>
</center>



<!--CSS INCLUDE WITH HTML-->
<head>
<style>

input[type=text]{
    width: 100%;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;

}

input[type=Date]{
    width: 100%;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: white;

}
input[type=submit]{
    
 
    bottom: 100%;
    background-color: black;
    color: white;
    font-size: 16px;

    padding: 8px 50px;
    border: none;
    cursor: pointer;
    border-radius: 25px;
    text-align: center;

}






</style>
</head>
<center>
<body style="background-color:teal;">


<form action="" method="post">
	<table>
		<tr>
        	<td>ID</td>
            <td><input type="text" name="add_ID"></td>
        </tr>
		<tr>
        	<td></td>
            <td><input type="submit" name="button_input"></td>
        </tr>
    	
    </table>
<form>
</center>

<?php 
	include 'connection.php';
	
	if(isset($_POST['button_input'])){
		
			$ai="";

	if($_SERVER["REQUEST_METHOD"]=="POST"){
			$ai=validate($_POST["add_ID"]);
			
			
			
			if ($ai!='')
		 {
			$sql = "DELETE FROM dashboard WHERE patient_id ='$ai'";
		 
		 }
		 
		 else{
			 echo "Plz write some data that you want to update";
		 }
		 
		 
		 
		 
		 
			//-------------------------------------------------------------------
			if(mysqli_query($conn, $sql) or die("Error: ".mysqli_error($conn)))
			{
			header ('Location:Action.php');	
			}
		else
			{
				
			echo ("Error Occured".mysqli_errno($conn));	
			}
			
	}
			
			
			
			
			
			
			//------------------------------------------
			
			
			
		}
		function validate($data){
			$data = trim($data);
			$data = stripcslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}	
	
	
?>
