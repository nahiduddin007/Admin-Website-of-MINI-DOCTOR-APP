<!DOCTYPE html>
<html>
<head >
<style>
body {background-color: powderblue; }

h1   {
	   background-color: blue;
       color: white;
     }

#example1 {
    border: 2px solid red;
    padding: 10px;
    border-bottom-left-radius: 25px;
}


</style>
<title>Doctor Page</title>
	<center>
	<b></b><h1>All DOCTORS LIST IN DHAKA HOSPITAL</h1></b>
	</center>
</head>
<br>
<br>
<br>
 



<body>

<div id="example1">
<p><b>অধ্যাপক ড. ফজলুল হক<br>
এমবিবিএস, বিসিপিএস-FRCP (এডিনবার্গ)<br>
FRCP (গ্লাসগো), FACP (ইউএসএ), বিসিপিএস (পাকিস্তান)<br>
অধ্যাপক, সাবেক প্রধান, মেডিসিন বিভাগ,<br>
ঢাকা মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: উত্তর ইন্টারন্যাশনাল মেডিকেল কলেজ ও হাসপাতাল<br>
বাড়ি # 84, রোড # 8/এ (নতুন) ধানমন্ডি, ঢাকা – ১২০৯<br>
ফোন: + ৮৮০-2-8156914, 8156839, 9133505, 9111381,<br>
মোবাইল: + ৮৮০-1674058435, + ৮৮০ 1715153935</div>
<br><br><br>

<div id="example1">
প্রফেসর ড. শেখ Nesaruddin আহমেদ<br>
এমবিবিএস, DTM & H, ৪ঃ (Edin), FRCP (Edin), বিসিপিএস<br>
প্রাক্তন অধ্যাপক ও প্রধান, মেডিসিন বিভাগ<br>
ঢাকা মেডিকেল কলেজ হাসপাতাল।<br>
চেম্বার: ল্যাবএইড কার্ডিয়াক হাসপাতাল<br>
হাউজ # ১, রোড # 4, ধানমন্ডি, ঢাকা – ১২০৫<br>
ফোন: + 880-2-8610793-8, 3-9670210, 8631177</div>
<br><br><br>

<div id="example1">
প্রফেসর ড. এইচ এ এম নাজমুল আহসান<br>
এমবিবিএস, বিসিপিএস-FRCP (গ্লাসগো) FRCP (Edin), FACP (ইউএসএ)<br>
অধ্যাপক মেডিসিন<br>
ঢাকা মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিমিটেড<br>
হাউজ-11/এ, রোড-২, ধানমন্ডি আ / এ, ঢাকা-১২০৫, বাংলাদেশ<br>
ফোন: + ৮৮০-2-3-9669480, 9661491</div>
<br><br><br>

<div id="example1">
প্রফেসর ড. ফেরদৌস আরা জে Janan<br>
এমবিবিএস, MD (মার্কিন যুক্তরাষ্ট্র), FIBA (ইঞ্জিনিয়ার), বিসিপিএস (মেদ।),<br>
FRCP (Edin.), FACP (ইউএসএ)<br>
মেডিসিন বিভাগ, DMC ও উচ্চশিক্ষায় অনলিমেহেদি প্রধান<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিঃ, শ্যামলী শাখার<br>
বাড়ী # (22/7) 29, বীর উত্তম নুরুজ্জামান A.N.M Sorak,<br>
(Babor রোড) ব্লক # বি, মোহাম্মদপুর, ঢাকা-১২০৭<br>
ফোন: + ৮৮০-2 – 9111911
</div>
<br><br><br>

<div id="example1">
PROF.(DR) কে এম মূসা<br>
ডায়াবেটিস, মেডিসিন<br>
এমবিবিএস, DTCD, বিসিপিএস, MCPS, সোনার পদকজয়ী<br>
চেম্বার: AALOK স্বাস্থ্য লিমিটেড<br>
হাউজ # 1 ও ৩, রোড # 2, ব্লক # বি, সেকশন-10<br>
মিরপুর, ঢাকা-১২১৬<br>
টেলিফোন: 02-9007678, 01915448491-9012274 উন্মত্ত</div><br><br><br>

<div id="example1">
অধ্যাপক ড. N.I. খান<br>
এমবিবিএস, MRCP(U.K), FRCP, FACP(USA)<br>
অধ্যাপক ও মেডিসিন বিভাগের প্রধান<br>
ঢাকা মেডিকেল কলেজ হাসপাতাল।<br>
চেম্বার: মনোয়ারা হাসপাতাল (প্রাইভেট) লিমিটেড<br>
54, সিদ্ধেশ্বরী রোড, ঢাকা – ১২১৭<br>
ফোন: + ৮৮০-2-831-8135, 831-9802</div><br><br><br>
<div id="example1">
প্রফেসর ড. মির্জা মোহাম্মদ Hiron<br>
বিসিপিএস (মেডিসিন), মোঃ (ছাতি), FCCP (ইউএসএ),<br>
FRCP (আয়ারল্যান্ড), FRCP (Edin), FRCP (গ্লাসগো)<br>
অধ্যাপক ও পরিচালক, রেসপিরেটরি মেডিসিন<br>
জাতীয় রোগ ইনস্টিটিউট হাসপাতাল এবং বুকে<br>
চেম্বার: ইবনে সিনা ডায়াগনস্টিক ও চিত্রায়ন কেন্দ্র<br>
হাউজ # 48, রোড # 9/এ, ধানমন্ডি<br>
সাতমসজিদ রোড, ঢাকা – ১২০৯<br>
ফোন: + ৮৮০-2-9126625-9128835-7, + ৮৮০ 1717351631</div><br><br><br>
<div id="example1">
প্রফেসর ড. A.B.M দেওয়া<br>
এমবিবিএস, MRCP(UK), FRCP<br>
অধ্যাপক ও চেয়ারম্যান<br>
বঙ্গবন্ধু শেখ মুজিব মেডিকেল বিশ্ববিদ্যালয়<br>
চেম্বার: সেন্ট্রাল ফিজিওথেরাপি সেন্টার<br>
18, গ্রীন রোড, ঢাকা-1205<br>
ফোন: + 880-2-96773496-8624514-8 ext-8201</div><br><br><br>
<div id="example1">
অধ্যাপক ডাঃ পরিতোষ কুমার বড়াল<br>
এমবিবিএস, বিসিপিএস-মোঃ<br>
অধ্যাপক ও বিভাগের প্রধান<br>
Z.H. শিকদার মেডিকেল কলেজ, ঢাকা।<br>
চেম্বার: সিটি হাসপাতাল লিঃ<br>
1/8, ব্লক-ই, লালমাটিয়া, সাত মসজিদ রোড,<br>
মোহাম্মদপুর, ঢাকা-১২০৭, বাংলাদেশ<br>
ফোন: + ৮৮০-2-8143312, 8143437, 8143166</div><br><br><br>
<div id="example1">
প্রফেসর ড. মোঃ Julhas উদ্দিন<br>
এমবিবিএস, ভুতে মেদ (আফমি), বিসিপিএস (মেদ)<br>
প্রফেসর এন্ড হেড<br>
Tairunnessa মেমোরিয়াল মেডিক্যাল কলেজ ও হাসপাতাল<br>
চেম্বার: সামরিক বাহিনীর মেডিকেল কলেজ AFMC –<br>
House # 13/A, Road # 35, Gulshan # 2, Dhaka-1212<br>
Phone: +880-2-8835981-4, 8858943, +880 152463101</div><br><br><br>
<div id="example1">
Professor Dr. Md. Manjur Rahman ( Galib )<br>
MBBS, FCPS ( Medicine )<br>
Internal Medicine<br>
Labaid Specialized Hospital, Dhanmondi, Dhaka<br>
Chamber: Labaid Specialized Hospital<br>
House # 6, Road # 4, Dhanmondi, Dhaka – 1205<br>
Phone: + 880-2-9676356, 8610793-8</div><br><br><br>
<div id="example1">
Professor Dr. Kamal Sayeed Ahmed Chowdhury<br>
MBBS, FCPS, MACP<br>
Professor, Department of Medicine<br>
Northern International Medical College<br>
Chamber: Northern International Medical College & Hospital<br>
House # 48, Road # 9/A, Satmasjid RoadDhanmondi, Dhaka – 1209<br>
ফোন: + ৮৮০-2-8156914, 8156839, 9111381, মোবাইল: + ৮৮০ 1674058435</div><br><br><br>

<div id="example1">
প্রফেসর ড. A.K.M. রফিক উদ্দিন<br>
এমবিবিএস, MD (মার্কিন যুক্তরাষ্ট্র), বিসিপিএস (মেডিসিন), FACP (ইউএসএ)<br>
প্রফেসর এন্ড হেড, ডিপার্টমেন্ট অফ মেডিসিন<br>
সাভারের এনাম মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিমিটেড<br>
হাউজ # ১৬, রোড # 2, পশ্চিম ধানমণ্ডি আ / এ, ঢাকা – ১২০৫<br>
ফোন: + ৮৮০-2-9669480-9661491-3, মোবাইল-01553341060-1</div><br><br><br>
<div id="example1">
প্রফেসর ড. আবুল কাশেম, খন্দকার<br>
এমবিবিএস, পিএইচডি, বিসিপিএস, FACP, FRCP<br>
অধ্যাপক মেডিসিন<br>
শহীদ সোহরাওয়ার্দী মেডিকেল কলেজ, ঢাকা<br>
চেম্বার: পদ্মা ডায়াগনস্টিক সেন্টার লিমিটেড<br>
245/2 নতুন সার্কুলার রোড, মালিবাগ, ঢাকা-১২১৭<br>
ফোন: + ৮৮০-2-9350383, 9351237, 9351424, 9352641</div><br><br><br>
<div id="example1">
প্রফেসর ড. আতাউর রহমান চৌধুরী<br>
এমবিবিএস, DTM ও H(Eng.), MRCP(UK), FRCP(Edin)
অধ্যাপক<br>
ডেল্টা মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: ডেল্টা মেডিকেল কলেজ ও হাসপাতাল<br>
26/2, প্রিন্সিপাল আবুল কাশেম RoadMirpur-1, ঢাকা-১২১২<br>
Phone: +880-2-8017151-52, 8031378-79V<br>
চেম্বার: ইবনে সিনা মেডিকেল চিত্রায়ন কেন্দ্র
হাউজ # 58, রোড # ২ /,<br>
ধানমন্ডি আ / এ, ঢাকা – ১২০৯<br>
Phone: +880-2-8618262, 8618007, 8610420</div><br><br><br>
<div id="example1">
প্রফেসর ড. মো: আবদুল জলিল চৌধুরী<br>
এমবিবিএস, বিসিপিএস-মোঃ FACP (মার্কিন যুক্তরাষ্ট্র)<br>
অধ্যাপক, মেডিসিন বিভাগ<br>
বঙ্গবন্ধু শেখ মুজিব মেডিকেল বিশ্ববিদ্যালয় (উচ্চশিক্ষায়)<br>
চেম্বার: ল্যাবএইড স্পেশালাইজড হসপিটাল<br>
House # 6, Road # 4, Dhanmondi, Dhaka – 1205<br>
ফোন: + 880 2 9676356-8610793-8</div><br><br><br>
<div id="example1">
অধ্যাপক ডাঃ মানবেন্দ্রনাথ নাথ নাগ<br>
এমবিবিএস (ঢাকা), বিসিপিএস (মেডিসিন)<br>
প্রধান, মেডিসিন বিভাগ<br>
শিব উইমেন্স মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিমিটেড<br>
অবস্থান: বাড়ি-11/এ, রোড-২, ধানমন্ডি আ / এ, ঢাকা-১২০৫<br>
Phone: +880-2-9669480, 9661491-2</div><br><br><br>
<div id="example1">
প্রফেসর ড. Lutful কবীর<br>
এমবিবিএস, FRCP (ইউকে)<br>
অধ্যাপক, মেডিসিন বিভাগ<br>
বাংলাদেশ মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: ইবনে সিনা ডায়াগনস্টিক ও চিত্রায়ন কেন্দ্র<br>
হাউজ # 48, রোড # 9/এ, সাত মসজিদ রোড<br>
ধানমন্ডি, ঢাকা – ১২০৯, বাংলাদেশ<br>
ফোন: + ৮৮০-2-9126625-6-9128835-7, সেল: + ৮৮০ 1717351631</div><br><br><br>
<div id="example1">
প্রফেসর ড. Kaniz Moula<br>
বিসিপিএস-FRCP (Edin, ইউকে), FACP (ইউএসএ)<br>
প্রধান, মেডিসিন বিভাগ<br>
পবিত্র ফ্যামিলি রেড ক্রিসেন্ট মেডিকেল কলেজ হাসপাতা<br>
চেম্বার: পদ্মা ডায়াগনস্টিক সেন্টার<br>
245/2, Malibahg, নিউ সার্কুলার রোড, ঢাকা – ১২১৭<br>
ফোন: + ৮৮০-2-8311721-25 (O), 9350383, 9351237</div><br><br><br>
<div id="example1">
এমেরিটাস অধ্যাপক ডাঃ হাজেরা মাহতাব<br>
এমবিবিএস, DTM & H-বিসিপিএস-FRCP(Edin)<br>
ইব্রাহিম জেনারেল হসপিটাল এন্ড DCEC, ধানমন্ডি<br>
চেম্বার: ইব্রাহিম জেনারেল হাসপাতাল ও DCEC, ধানমন্ডি<br>
হাউজ # 42, রোড #10/এ, ধানমন্ডি, ঢাকা<br>
ফোন: + ৮৮০-2 - 9146357 (চেম্বার)</div><br><br><br>

<div id="example1">
অধ্যাপক ডাঃ কাজী মোঃ জাহাঙ্গীর<br>
এমবিবিএস (পাঠিয়ে ৷), বিসিপিএস (Med.), FACP (ইউএসএ)<br>
মেডিসিন বিভাগের সাবেক প্রধান<br>
রংপুর মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিমিটেড<br>
হাউজ-11/এ, রোড-২, ধানমন্ডি আ / এ, ঢাকা-১২০৫<br>
ফোন: + ৮৮০-2-3-9669480, 9661491</div><br><br><br>
<div id="example1">
প্রফেসর ড. খান আবুল কালাম আজাদ<br>
এমবিবিএস (DMC) বিসিপিএস (মেডিসিন)<br>
অধ্যাপক মেডিসিন<br>
ঢাকা মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিমিটেড<br>
হাউজ-11/এ, রোড-২, ধানমন্ডি আ / এ, ঢাকা-১২০৫, বাংলাদেশ<br>
ফোন: + ৮৮০-2-9661491-3, 9669480, 01553341060, 01553341061</div><br><br><br>
<div id="example1">
প্রফেসর ড. এম এ আজহার<br>
এমবিবিএস, বিসিপিএস, FACP, FRCP (Edin)<br>
মূল ও প্রধান, মেডিসিন বিভাগ<br>
স্যার সলিমুল্লাহ মেডিকেল কলেজ ও হাসপাতাল Mitford<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিমিটেড<br>
হাউজ # ১৬, রোড # 2, পশ্চিম ধানমণ্ডি আ / এ, ঢাকা – ১২০৫<br>
ফোন: + ৮৮০-2-9669480-9661491-3, 01553341060-1</div><br><br><br>
<div id="example1">
প্রফেসর ড. এম এ ফায়েজ<br>
এমবিবিএস, বিসিপিএস-FRCP (Edin), পিএইচডি (যুক্তরাজ্য)<br>
অধ্যাপক, মেডিসিন বিভাগ<br>
স্যার সলিমুল্লাহ মেডিকেল কলেজ, Mitford হাসপাতাল, ঢাকা<br>
চেম্বার: ল্যাব হাসপাতাল লি:<br>
হাউজ # ১, রোড # 4, ধানমন্ডি, ঢাকা – ১২০৫<br>
ফোন: + 880 2 8610793-8, 9670210-3, 8631177 (চেম্বার)</div><br><br><br>
<div id="example1">
প্রফেসর ড. এম এ ওয়াহাব<br>
এমবিবিএস, MRSH(London), FICA(USA), ৪ঃ, DTCD, FRCP<br>
অধ্যাপক<br>
পবিত্র ফ্যামিলি রেড ক্রিসেন্ট মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: ডাক্তাররা ডায়াগনস্টিক সেন্টার লি:
রোড # ৭, ধানমন্ডি, ঢাকা – ১২০৫<br>
Phone: +880-2- 9123060</div><br><br><br>
<div id="example1">
প্রফেসর ড. এ আর এম সাইফুদ্দিন ইকরাম<br>
Ph.D.(USA), FACP(USA), বিসিপিএস<br>
অধ্যাপক ও বিভাগের প্রধান<br>
রাজশাহী মেডিকেল কলেজ<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিঃ, শ্যামলী শাখার<br>
বাড়ী # (22/7) 29, বীর উত্তম A.N.M নুরুজ্জামান Sorak<br>
(Babor রোড) ব্লক # বি, মোহাম্মদপুর, ঢাকা-১২০৭<br>
ফোন: + ৮৮০-2 - 9111911</div><br><br><br>
<div id="example1">
অধ্যাপক ডাঃ মোঃ এনামুল করিম<br>
এমবিবিএস, বিসিপিএস (মেডিসিন), FACP (ইউএসএ) হু সহযোগী (Diabetics)<br>
অধ্যাপক মেডিসিন<br>
ঢাকা মেডিকেল কলেজ হাসপাতাল।<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিমিটেড, ধানমন্ডি শাখা<br>
হাউজ # ১৬, রোড # 2, পশ্চিম ধানমণ্ডি আ / এ, ঢাকা – ১২০৫<br>
ফোন: + ৮৮০-2-9669480-9661491-3, মোবাইল-01553341060-1</div><br><br><br>
<div id="example1">
প্রফেসর ড. মো: আজিজুল বারী<br>
এমবিবিএস, বিসিপিএস (Med.), D.Card<br>
অধ্যাপক, কার্ডিওলজি, BIRDEM সাবেক প্রধান<br>
চেম্বার: উত্তর ইন্টারন্যাশনাল মেডিকেল কলেজ ও হাসপাতাল<br>
হাউজ # 48, রোড # 9/এ, সাত মসজিদ রোড<br>
ধানমন্ডি, ঢাকা – ১২০৯, বাংলাদেশ<br>
ফোন: + ৮৮০-2-8156914, 8156839, 9133505, + ৮৮০ 1674058435</div><br><br><br>

<div id="example1">
অধ্যাপক ডাঃ মোঃ ফজলুল কাদির<br>
এমবিবিএস, বিসিপিএস<br>
অধ্যাপক<br>
বাংলাদেশ মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: Medinova:<br>
হাউজ # 71/এ, রোড # 5/এ, ধানমন্ডি আ / এ, ঢাকা।<br>
Phone: +880-2-8620353-6, 8624907-10</div><br><br><br>
<div id="example1">
প্রফেসর ড. মো: শাহীন চৌধুরী<br>
এমবিবিএস, বিসিপিএস (মেডিসিন)<br>
অধ্যাপক, মেডিসিন বিভাগ<br>
পবিত্র ফ্যামিলি রেড ক্রিসেন্ট মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: ইবনে সিনা ডায়াগনস্টিক ও চিত্রায়ন কেন্দ্র<br>
হাউজ # 48, রোড # 9/এ, সাতমসজিদ রোড, ধানমন্ডি, ঢাকা – ১২০৯<br>
ফোন: + ৮৮০-2-9126625-6-9128835-7, সেল: + ৮৮০ 1717351631</div><br><br><br>
<div id="example1">
প্রশ্ন: অধ্যাপক ড. Tarikul ইসলাম<br>
এমবিবিএস, বিসিপিএস-FACP (মার্কিন যুক্তরাষ্ট্র), FRCP<br>
অধ্যাপক মেডিসিন<br>
ঢাকা মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: জনপ্রিয় ডায়াগনস্টিক সেন্টার লিমিটেড<br>
হাউজ-11/এ, রোড-২, ধানমন্ডি আ / এ, ঢাকা-১২০৫<br>
ফোন: + ৮৮০-2-3-9669480, 9661491</div><br><br><br>
<div id="example1">
প্রফেসর ড. মোঃ Zilan মিয়া সরকার<br>
এমবিবিএস, বিসিপিএস (মেডিসিন)<br>
অধ্যাপক মেডিসিন<br>
বঙ্গবন্ধু শেখ মুজিব মেডিকেল বিশ্ববিদ্যালয় (উচ্চশিক্ষায়)<br>
চেম্বার: কমফোর্ট ডায়াগনস্টিক সেন্টার<br>
167 গ্রীন রোড, ঢাকা – ১২০৫<br>
ফোন: + ৮৮০-2-8124990, 8129667, 8124380</div><br><br><br>
<div id="example1">
প্রফেসর ড. এ কে এম মোশাররফ হোসেন<br>
এমবিবিএস, বিসিপিএস-FCCP(USA)<br>
শ্বাস-প্রশ্বাসজনিত বিভাগের অধ্যাপক<br>
ঘুম ও শ্বাস-প্রশ্বাসজনিত ওষুধ<br>
বঙ্গবন্ধু শেখ মুজিব মেডিকেল বিশ্ববিদ্যালয়<br>
চেম্বার: ল্যাবএইড স্পেশালাইজড হসপিটাল<br>
রোড # 4, হাউজ # 6, ধানমন্ডি, বাংলাদেশ<br>
Phone: +880-2-9676356, 8610793-8</div><br><br><br>
<div id="example1">
প্রফেসর ড. মো: Muzibur রহমান ভুইয়া<br>
এমবিবিএস, বিসিপিএস (ওষুধ) মোঃ (Gastroenterology)<br>
কোঅর্ডিনেটর ও সিনিয়র কনসালটেন্ট<br>
এ্যাপোলো হাসপাতাল ঢাকা<br>
চেম্বার: এ্যাপোলো হসপিটালস ঢাকা<br>
অবস্থান: প্লট # 81, ব্লক # ই, Basudhara সি / এ, ঢাকা – ১২১৯<br>
ফোন: + ৮৮০-2-8401661, 8845242, মোবাইল: + ৮৮০ 1841276556</div><br><br><br>
<div id="example1">
প্রফেসর ড. Anowarul কবির<br>
এমবিবিএস, ৪ঃ, FRCP, FCGE (ইউকে)<br>
সিনিয়র কনসালটেন্ট<br>
এ্যাপোলো হসপিটালস ঢাকা<br>
চেম্বার: এ্যাপোলো হসপিটালস ঢাকা<br>
অবস্থান: প্লট # 81, ব্লক # ই, Basudhara সি / এ, ঢাকা – ১২১৯<br>
ফোন: + ৮৮০-2-8401661, 8845242, মোবাইল: + ৮৮০-1841276556, <br>হটলাইন: 10678</div><br><br><br>
<div id="example1">
অধ্যাপক ডাঃ বি বি বড়ুয়া<br>
এমবিবিএস, পিএইচডি (আমেরিকা), FCGP, এমবিবিএস, সহকর্মী, WHO (জেনেভা)<br>
পরামর্শক ও অধ্যাপক<br>
ভেতর থেকে ওষুধ<br>
চেম্বার: জাপান বাংলাদেশ ফ্রেন্ডশীপ হসপিটাল<br>
55, সাত মসজিদ রোড (Zigatola বাস স্ট্যান্ড), ঢাকা – ১২০৯<br>
Phone: +880-2-9672277, 9676161, 9664028, 9664029</div><br><br><br>
<div id="example1">
প্রফেসর ড. মোহাম্মদ আজিজুল kahar<br>
এমবিবিএস, (ইউ কে)-৪ঃ বিসিপিএস<br>
অধ্যাপক<br>
ভেতর থেকে ওষুধ<br>
ঢাকা মেডিকেল কলেজ ও হাসপাতাল<br>
চেম্বার: স্পাইস খান মডার্ন হাসপাতাল লি:<br>
হাউজ # 17, রোড # 8, ধানমন্ডি, ঢাকা-১২০৫।<br>
ফোন: + ৮৮০-2-9661213, 9670295, 9667985 Ext-431</div><br><br><br>
<div id="example1">
প্রফেসর ড: মাহবুব আনোয়ার<br>
এমবিবিএস, DTCD, MD, FCCP (ইউএসএ), FRCP (Edin)<br>
অধ্যাপক<br>
Z.H. শিকদার মেডিক্যাল কলেজ ও হাসপাতাল<br>
চেম্বার: সেন্ট্রাল হাসপাতাল লিমিটেড<br>
অবস্থান: বাড়ি # ৫, রোড # ২, ঢাকা – ১২০৫<br>
ফোন: + ৮৮০-2-9660015-19, Ext-8904</div><br><br><br>
<div id="example1">
প্রফেসর ড. মো: Faizul ইসলাম চৌধুরী<br>
এমবিবিএস, FCPS(medicine)<br>
কনসালটেন্ট<br>
ভেতর থেকে ওষুধ<br>
এ্যাপোলো হসপিটালস ঢাকা<br>
চেম্বার: এ্যাপোলো হসপিটালস ঢাকা<br>
প্লট # 81, ব্লক # ই, Basudhara সি / এ, ঢাকা – ১২১৯<br>
ফোন: + ৮৮০-2-8401661, 8845242, মোবাইল: + ৮৮০ 1841276556</div><br><br><br>
<div id="example1">
ড. ইকবাল মোরশেদ কবীর<br>
এমবিবিএস, বিসিপিএস (ওষুধ) মোঃ (Gastroenterology)<br>
কনসালটেন্ট<br>
এ্যাপোলো হাসপাতাল ঢাকা<br>
চেম্বার: এ্যাপোলো হসপিটালস ঢাকা<br>
Plot # 81, Block # E, Basudhara R/A, Dhaka – 1229<br>
Phone: +880-2-8401661, 8845242, Cell: +880 1841276556</div><br><br><br>
<div id="example1">
Dr. M. A. Mannan<br>
MBBS, MRCP ( UK ) , ECFMG ( USA ) ,<br>
Associate Professor<br>
Delta Medical College<br>
Chamber: Central Hospital Limited<br>
House # 2, Road # 5, Green Road, Dhanmondi, Dhaka – 1205<br>
Phone: +880 2 9660015-19</div><br><br><br>
<div id="example1">
Dr. Mohammad Enamul Haque<br>
MBBS, DTCD, FCPS<br>
Associate Professor & Head of Department<br>
Respiratory Medicine<br>
Dhaka Medical College Hospital<br>
Chamber: The Medical Centre<br>
Location: House # 84, Road # 7/A, ShaMasjid Road<br>
Dhanmondi, Dhaka<br>
Phone: +880-2- 9118219</div><br><br><br>

<div id="example1">
Dr. Sohel Mahmud Arafat<br>
MBBS, FCPS<br>
Associate Professor<br>
Bangabandhu Sheikh Mujib Medical University ( BSMMU )<br>
Chamber: Ibn Sina Diagnostic & Imaging Center<br>
Location: House # 48, Road # 9/A, Satmasjid Road<br>
Dhanmondi, Dhaka – 1209, Bangladesh<br>
Phone: +880-2-9126625-6, 9128835-7, Cell: +880 1717351631</div><br><br><br>
<div id="example1">
Dr. Muhammad Jahir Uddin<br>
MBBS, FCPS ( Medicine ), MD ( Internal Medicine ), MACP ( USA )<br>
Associate Professor<br>
Dhaka Medical College & Hospital<br>
Chamber: Ibn Sina Diagnostic & Imaging Center<br>
House # 48, Road # 9/A, Dhanmondi, SAtmasjid Road<br>
Dhaka – 1209, Bangladesh<br>
Phone: +880-2-9128835-7, 9126625-6, +880 1717351631</div><br><br><br>
<div id="example1">
Lt. Col. Dr. Md. Niamul Gani Chowdhury<br>
MBBS, FCPS ( Medicine ), Diploma Gastroenterology ( China )<br>
Associate Professor, Medicine Department<br>
Armed Forces Medical College, Dhaka<br>
Chamber: Aysha Memorial Specialised Hospital<br>
Location: 74 /G/ 75, Peacock Square, New Airport Road<br>
Mohakhali, Dhaka -1215, Bangladesh<br>
Phone: +880-2-9122689, 9122690, Mobile – 01919372647, 01915490004</div><br><br><br>
<div id="example1">
Dr. Md. Abul Kalam Azad<br>
MBBS, FCPS<br>
Associate Professor<br>
Bangabandhu Sheikh Mujib Medical University<br>
Chamber: Padma Diagnostic Center Ltd<br>
245/2, New Circular Road, Malibagh, Dhaka, Bangladesh<br>
Phone: +880-2-9350383, 9351237, 9351424, 9352641</div><br><br><br>
<div id="example1">
Dr. Mohammad Hyder Ali<br>
MBBS, FCPS<br>
Associate Professor<br>
Medicine<br>
Bangladesh Medical College & Hospital, Dhaka, Bangladesh<br>
Chamber: City Hospital Ltd.<br>
1/8, Block-E, Lalmatia, Satmosjid Road, Mohammadpur,<br>
Dhaka – 1207, Bangladesh<br>
Phone: +880-2-8143312,8143167, 9124436, 01715024100</div><br><br><br>
<div id="example1">
Dr. Md. Billal Alam<br>
MBBS, FCPS, MACP, FACP(USA)<br>
Associate Professor<br>
Dhaka Medical College & Hospital<br>
Chamber: Popular Diagnostic Centre Ltd. – Shyamoli Branch<br>
Hous# (22/7)29, Bir Uttam A.N.M Nuruzzaman Sorak, (Babor road)<br>
Block# b, Mohammadpur, Dhaka-1207, Bangladesh<br>
Phone: +880-2- 9111911</div><br><br><br>
<div id="example1">
Dr. Anup Kumar Saha<br>
MBBS, FCPS ( Medicine ), MD ( Internal Medicine ), FACP ( America )<br>
Associate Professor<br>
Sir Salimullah Medical College and Mitford Hospital<br>
Chamber: Health & Hope Hospital Ltd.<br>
152/1-H, Green Road, Panthapath<br>
Dhaka – 1205, Bangladesh<br>
Phone: +880-2-9145786, 9137076, 01819494530<br>
Chamber: Monowara Hospital (Pvt) Ltd<br>
Location: 54, Siddeshwari Road, Dhaka- 1217<br>
Phone: +880-2-8318135, 8319802</div><br><br><br>
<div id="example1">
Dr. M.A. Rashid<br>
MBBS, FCGP, MPH, CCD<br>
Associate Professor<br>
Bangladesh College of General Practitioners<br>
Chamber: Medison Diagnostic Center<br>
3, Darus Salam Road, Mirpur-1, Dhaka<br>
Phone: +880-2-9002292, 9000089</div><br><br><br>
<div id="example1">
Dr. Md. Golam Kibria Khan<br>
MBBS (Dhaka), FCPS (Medicine),<br>
MACP (USA), FACP (USA), Rheumatology Fellow (USA)<br>
Associate Professor<br>
Dhaka Medical College & Hospital<br>
Chamber: Popular Diagnostic Centre Ltd<br>
Location: House-11/A, Road-2, Dhanmondi R/A<br>
Dhaka-1205, Bangladesh<br>
Phone: +880-2-9669480, 9661491-3</div><br><br><br>
<div id="example1">
Dr.Rajashish Chakraborty<br>
MBBS, FCPS, MD<br>
Assistant Professor
Dhaka National Medical College & Hospital<br>
Chamber: Delta Medical College & Hospital<br>
26/1 Darus Salam Road, Mirpur<br>
Phone: +880 1711827878</div><br><br><br>

<div id="example1">
Dr. Mahmudul Huque<br>
MBBS, MD ( Endocrinology )<br>
Assistant Professor, Department of Medicine<br>
Holy Family Red Crescent Hospital<br>
Chamber: Ibn Sina Diagnostic & Imaging Center<br>
Location: House # 48, Road # 9/A, Dhanmondi,<br>
SAtmasjid Road, Dhaka – 1209, Bangladesh<br>
Phone: +880-2-9126625, 9128835-7,+880 1717351631</div><br><br><br>
<div id="example1">
Dr. Md. Zaid Hossain<br>
MBBS, MRCP<br>
Assistant professor, Department of Medicine<br>
Dhaka Medical College<br>
Chamber: Labaid Cardiac Hospital<br>
Location: House # 1, Road # 4, Dhanmondi, Dhaka – 1205<br>
Phone: + 880-2-8610793 – 8, 9670210 – 3</div><br><br><br>
<div id="example1">
Dr. Uttam Kumar Barua<br>
MBBS, DTCD<br>
Assistant Professor<br>
Shaheed Suhrawardy Medical College and Hospital<br>
Chamber: Popular Diagnostic Centre Ltd. – Shyamoli Branch<br>
House# (22/7)29, Bir Uttam A.N.M Nuruzzaman Sorak,<br>
(Babor road) Block# b, Mohammadpur, Dhaka-1207<br>
Phone: +880-2- 9111911</div><br><br><br>
<div id="example1">
Dr. Kazi Saifuddin Bennoor<br>
MBBS, DTCD<br>
Assistant Professor<br>
National Institute of Disease of Chest & Hospital<br>
Chamber: Medinova Medical Services Ltd.<br>
House # 71/A, Road # 5/A, Dhanmondi R/A, Dhaka.<br>
Phone: +880-2-8620353-6</div><br><br><br>
<div id="example1">
Dr. Samiron Kumar Saha<br>
MBBS, PhD, FACP ( USA ) , FRCP ( Edin ),<br>
Senior Consultant<br>
Labaid Specialized Hospital – Dhanmondi, Dhaka<br>
Chamber: Labaid Specialized Hospital<br>
House # 1, Road # 4, Dhanmondi, Dhaka – 1205<br>
Phone: + 880-2-8610793-8, 9670210-3, 8631177</div><br><br><br>
<div id="example1">
Dr. Pradip R. Saha<br>
MBBS, FCPS<br>
Consultant<br>
United Hospital Limited, Gulshan, Dhaka, Bangladesh<br>
Chamber: United Hospital Limited<br>
Plot # 15, Road # 71, Gulshan – 2, Dhaka-1212, Bangladesh<br>
Phone: +880-2-8836000, 88364444</div><br><br><br>
<div id="example1">
Dr. Asmat Ahmed<br>
MBBS, MD (USA)<br>
Chamber: Labaid Specialized Hospital – Gulshan Branch<br>
Location: House # 13/A, Road # 35, Gulshan # 2, Dhaka-1212<br>
Phone: +880-2-8835981-4, 8858943, 8835966</div><br><br><br>
<div id="example1">
Dr. Md. Masudul Hasan<br>
MBBS, FCPS ( Medicine )<br>
Consultant<br>
Islami Bank Central Hospital<br>
Chamber: Islami Bank Central Hospital<br>
30, Anjuman-e-Mofidul Islam Road, Kakrail, Dhaka – 1000<br>
Phone: +880-2-9355801-2, 9360331-2</div><br><br><br>
<div id="example1">
Dr. Nazmul Ahsan<br>
MBBS, FCPS ( Medicine )<br>
Consultant<br>
Shaheed Suhrawardy Medical College (ShSMC)<br>
Chamber: Islam Diagnostic Lab<br>
Location: Near ASA Tower, Shamoli, Dhaka – 1207<br>
Phone: +880-2-8119815</div><br><br><br>
<div id="example1">
Dr. Parvin Akhter<br>
MBBS, MD<br>
Consultant, Medicine<br>
Central Hospital, Dhaka<br>
Chamber: Central Hospital Limited<br>
House # 5, Road # 2, Dhaka – 1205, Bangladesh<br>
Phone: + 880-2-9660016-19, 8624514-18 ( Chamber )</div><br><br><br>
<div id="example1">
Dr ( Col. ) S. M. Mamunur Rahman<br>
MBBS, FCPS ( Medicine )<br>
Classified Specialist in Medicine & Cardiologist<br>
Combined Military Hospital ( CMH ), Dhaka<br>
Chamber: Aysha Memorial Specialised Hospital<br>
74/G/75, Peacock Square, New Airport Road, Mohakhali<br>
Phone: +880-2-9122689, 9122690, 8142370, 8142371</div><br><br><br>
<div id="example1">
Dr. Ahmad Hossein Morshed<br>
MBBS, MD ( USA ), FCPS ( Medicine )<br>
Consultant<br>
City Hospital Ltd.<br>
Chamber: City Hospital Ltd.<br>
1/8, Block – E, Lalmatia, SAtmasjid ROad, Dhaka – 1207<br>
Phone: +880-2-8143312, 8143437, 8143167, 9124436</div><br><br><br>
<div id="example1">
Dr. Adnan Yusuf Chowdhury<br>
MBBS, MCPS, MD ( Chest Diseases )<br>
Consultant, Visiting<br>
United Hospital Limited<br>
Chamber: United Hospital Limited<br>
Plot # 15, Road # 71, Gulshan – 2, Dhaka – 1212, Bangladesh<br>
Phone: +880-2-8836000, 8836444</div><br><br><br>
<div id="example1">
Dr. A.B.M Sarwar-E-Alam<br>
MBBS, FCPS<br>
Consultant<br>
SQUARE Hospitals Ltd, Dhaka<br>
Chamber: SQUARE Hospitals Ltd.<br>
18/F West Panthapath, Dhaka – 1205, Bangladesh.<br>
Phone: +880 2 8159457, 8142431, 8141522, 8144400, 8142333</div><br><br><br>
<div id="example1">
Dr. Abu Reza Mohammad Nooruzzaman<br>
Consultant<br>
SQUARE Hospitals Ltd, Dhaka, Bangladesh<br>
Chamber: SQUARE Hospitals Ltd.<br>
18/F West Panthapath, Dhaka – 1205, Bangladesh.<br>
Phone: +880-2-8159457, 8142431, 8141522, 8144400, 8142333</div><br><br><br>
<div id="example1">
email: drnzaman@squarehospital.com<br>
Dr. Afsana Begum<br>
MBBS, FCPS<br>
Internal Medicine<br>
Organization: United Hospital Limited<br>
Chamber: United Hospital Limited<br>
Plot # 15, Road # 71, Gulshan – 2, Dhaka – 1212, Bangladesh<br>
Phone: +880-2-8836000, 8836444</div><br><br><br>
<div id="example1">
Dr. Jahangir Alam<br>
MBBS, (DMC), MRCP (UK)<br>
Consultant<br>
Internal Medicine<br>
SQUARE Hospitals Ltd, Dhaka, Bangladesh<br>
Chamber: SQUARE Hospitals Ltd.<br>
Location: 18/F West Panthapath, Dhaka – 1205, Bangladesh.<br>
Phone: +880-2-8159457, 8142431, 8141522, 8144400, 8142333</div><br><br><br>
<div id="example1">
Dr. Md. Tarek Alam<br>
MBBS, MD ( USA )<br>
Consultant, Visiting<br>
Internal Medicine<br>
United Hospital Limited, Gulshan, Dhaka, Bangladesh<br>
Chamber: United Hospital Limited<br>
Location: Plot # 15, Road # 71, Gulshan, Dhaka-1212, Bangladesh<br>
Phone: +880-2-8836000, 88364444</div>
<br><br><br>
 
</b> 



</p>

</body>
</html>