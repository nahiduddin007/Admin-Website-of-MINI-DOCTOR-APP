<!DOCTYPE html>
<html lang="en">
<head>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet">
	<meta charset="UTF-8">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<title>Dashboard</title>
    <link href="css_gird/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css_gird/normalize.css" rel="stylesheet" type="text/css">
    <link href="css_gird/demo.css" rel="stylesheet" type="text/css">
	<link href="css_gird/xopixel.css" rel="stylesheet" type="text/css">
</head>
<body>
	<header class="xopixel-header">
		<nav>
			<a href="index_login.php">Logout
		</a>
		</nav>
		<h1>Admin Page</h1>
		
	<div class="xop-section">
		<ul class="xop-grid">
			<li>
				<div class="xop-box xop-img-1">
					<a href="Action.php">
					<div class="xop-info">
						<h3>Doctors Appointment</h3>
						
					</div></a>
				</div>
			</li>




            <li>
				<div class="xop-box xop-img-4">
					<a href="doctor.php">
					<div class="xop-info">
						<h3>Consultant Doctor</h3>
						
					</div></a>
				</div>
			</li>


		</ul>
	</div>

</body>
</html>
